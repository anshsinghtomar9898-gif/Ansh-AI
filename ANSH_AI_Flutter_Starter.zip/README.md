# ANSH AI — Flutter starter

A blue-and-white Android app starter for ANSH AI.

## Included in this starter
- Home screen and bottom navigation
- Hindi-first AI chat interface (local UI demo only)
- Image generation placeholder
- Photo editing placeholder
- Voice assistant placeholder

## Important
This is a **starter source project**, not a fully working AI service yet. Chat, image generation, editing, speech recognition, speech playback, sign-in, payments, and daily image quotas require backend services and API credentials.

Never put private AI API keys inside the Android app. Add a backend that securely calls the AI provider and enforces account limits and payments.

## Run
1. Install Flutter SDK and Android Studio.
2. Extract this project.
3. From this folder run:
   ```bash
   flutter pub get
   flutter run
   ```
4. To build an APK:
   ```bash
   flutter build apk --release
   ```

## Suggested next development steps
1. Build a secure backend for chat and image generation.
2. Add image picker and image-editing endpoint.
3. Add speech-to-text and text-to-speech.
4. Add user accounts, payment verification, and server-side daily quotas.
5. Test privacy, safety, cost limits, and Android release signing before publishing.
