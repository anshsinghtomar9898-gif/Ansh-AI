import 'package:flutter/material.dart';

void main() => runApp(const AnshAiApp());

const navy = Color(0xFF123B70);
const blue = Color(0xFF2675D8);
const paleBlue = Color(0xFFEAF3FF);

class AnshAiApp extends StatelessWidget {
  const AnshAiApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ANSH AI',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: blue, brightness: Brightness.light),
        scaffoldBackgroundColor: const Color(0xFFF7FAFF),
        appBarTheme: const AppBarTheme(backgroundColor: Colors.white, foregroundColor: navy),
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int selected = 0;
  final pages = const [ChatPage(), ImagePage(), EditPage(), VoicePage()];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Row(children: [
          Icon(Icons.auto_awesome, color: blue),
          SizedBox(width: 9),
          Text('ANSH AI', style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: 1)),
        ]),
        actions: [IconButton(onPressed: () {}, icon: const Icon(Icons.account_circle_outlined))],
      ),
      body: Column(children: [
        Container(
          width: double.infinity,
          margin: const EdgeInsets.fromLTRB(16, 12, 16, 18),
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [navy, blue]),
            borderRadius: BorderRadius.circular(22),
          ),
          child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('नमस्ते अंश! 👋', style: TextStyle(color: Colors.white, fontSize: 23, fontWeight: FontWeight.bold)),
            SizedBox(height: 7),
            Text('AI सबके लिए — सिर्फ अमीरों के लिए नहीं।', style: TextStyle(color: Colors.white, fontSize: 14)),
          ]),
        ),
        Expanded(child: pages[selected]),
      ]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: selected,
        onDestinationSelected: (i) => setState(() => selected = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.chat_bubble_outline), label: 'Chat'),
          NavigationDestination(icon: Icon(Icons.image_outlined), label: 'Image'),
          NavigationDestination(icon: Icon(Icons.tune), label: 'Edit'),
          NavigationDestination(icon: Icon(Icons.mic_none), label: 'Voice'),
        ],
      ),
    );
  }
}

class ChatPage extends StatefulWidget {
  const ChatPage({super.key});
  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  final controller = TextEditingController();
  final messages = <String>[];

  @override
  void dispose() { controller.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.all(16),
    child: Column(children: [
      const FeatureHeader(icon: Icons.chat, title: 'AI Chat', subtitle: 'हिंदी या English में सवाल पूछें'),
      Expanded(child: messages.isEmpty
        ? const Center(child: Text('नमस्ते! ANSH AI में आपका स्वागत है।', textAlign: TextAlign.center))
        : ListView.builder(itemCount: messages.length, itemBuilder: (_, i) => Align(
            alignment: Alignment.centerRight,
            child: Container(
              margin: const EdgeInsets.only(bottom: 10),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: paleBlue, borderRadius: BorderRadius.circular(15)),
              child: Text(messages[i]),
            ),
          ))),
      Row(children: [
        Expanded(child: TextField(controller: controller, decoration: const InputDecoration(
          hintText: 'अपना सवाल लिखें...', border: OutlineInputBorder(), filled: true, fillColor: Colors.white,
        ), onSubmitted: (_) => send())),
        const SizedBox(width: 8),
        IconButton.filled(onPressed: send, icon: const Icon(Icons.send)),
      ]),
      const SizedBox(height: 8),
      const Text('डेमो: असली AI जवाब के लिए backend/API जोड़ना बाकी है।', style: TextStyle(fontSize: 11, color: Colors.black54)),
    ]),
  );

  void send() {
    final text = controller.text.trim();
    if (text.isEmpty) return;
    setState(() { messages.add(text); controller.clear(); });
  }
}

class ImagePage extends StatelessWidget {
  const ImagePage({super.key});
  @override
  Widget build(BuildContext context) => const ToolPlaceholder(
    icon: Icons.image_search, title: 'AI Image Generator',
    subtitle: 'अपनी कल्पना लिखें और AI से तस्वीर बनवाएँ।',
    note: 'Image generation API जोड़ने के बाद यह सुविधा काम करेगी।',
    button: 'इमेज बनाएँ',
  );
}

class EditPage extends StatelessWidget {
  const EditPage({super.key});
  @override
  Widget build(BuildContext context) => const ToolPlaceholder(
    icon: Icons.auto_fix_high, title: 'Photo Editing',
    subtitle: 'फोटो चुनें और बदलाव का निर्देश दें।',
    note: 'फोटो चुनने और edit API जोड़ने का काम बाकी है।',
    button: 'फोटो चुनें',
  );
}

class VoicePage extends StatelessWidget {
  const VoicePage({super.key});
  @override
  Widget build(BuildContext context) => const ToolPlaceholder(
    icon: Icons.mic, title: 'Voice Assistant',
    subtitle: 'बोलकर सवाल पूछें और जवाब सुनें।',
    note: 'Microphone permission और speech-to-text / text-to-speech जोड़ना बाकी है।',
    button: 'Voice शुरू करें',
  );
}

class FeatureHeader extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  const FeatureHeader({super.key, required this.icon, required this.title, required this.subtitle});
  @override
  Widget build(BuildContext context) => Container(
    width: double.infinity, margin: const EdgeInsets.only(bottom: 14), padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(color: paleBlue, borderRadius: BorderRadius.circular(18)),
    child: Row(children: [
      CircleAvatar(backgroundColor: Colors.white, child: Icon(icon, color: blue)),
      const SizedBox(width: 12),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17, color: navy)),
        Text(subtitle, style: const TextStyle(fontSize: 12, color: Colors.black54)),
      ])),
    ]),
  );
}

class ToolPlaceholder extends StatelessWidget {
  final IconData icon;
  final String title, subtitle, note, button;
  const ToolPlaceholder({super.key, required this.icon, required this.title, required this.subtitle, required this.note, required this.button});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.all(16),
    child: Column(children: [
      FeatureHeader(icon: icon, title: title, subtitle: subtitle),
      const Spacer(),
      Icon(icon, size: 76, color: blue),
      const SizedBox(height: 16),
      Text(note, textAlign: TextAlign.center, style: const TextStyle(color: Colors.black54)),
      const SizedBox(height: 20),
      FilledButton(onPressed: () => ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('यह सुविधा API जोड़ने के बाद उपलब्ध होगी।')),
      ), child: Text(button)),
      const Spacer(),
    ]),
  );
}
